document.addEventListener('DOMContentLoaded', function() {
    const toggleButton = document.querySelector('.toggle-visibility');
    const olhoImagem = document.getElementById('olho-imagem');
    const saldoElement = document.getElementById('saldo');
    let saldoVisivel = false; // Inicialmente o saldo está oculto
  
    toggleButton.addEventListener('click', function() {
      if (saldoVisivel) {
        // Ocultar saldo e mostrar olho fechado
        saldoElement.textContent = '******'; // Ou qualquer outra forma de ocultar
        olhoImagem.src = '/Tudo/index/indext/img.index/olhofpreto.png'; // Caminho para o olho fechado
        olhoImagem.alt = 'Mostrar Saldo';
        saldoVisivel = false;
      } else {
        // Mostrar saldo e mostrar olho aberto
        saldoElement.textContent = '1.234,56'; // Substitua pelo valor real do saldo
        olhoImagem.src = '/Tudo/index/indext/img.index/olhoa'; // Caminho para o olho aberto
        olhoImagem.alt = 'Ocultar Saldo';
        saldoVisivel = true;
      }
    });
  });